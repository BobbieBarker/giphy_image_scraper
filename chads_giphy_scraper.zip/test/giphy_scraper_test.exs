defmodule GiphyScraperTest do
  use ExUnit.Case
  doctest GiphyScraper

  test "greets the world" do
    assert GiphyScraper.hello() == :world
  end
end
