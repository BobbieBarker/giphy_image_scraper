defmodule GiphyImage do
  defstruct [:id, :url, :title, :author]
end
