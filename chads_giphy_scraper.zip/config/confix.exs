use Mix.Config
IO.puts "blah blah blah blah blah"
config :giphy_scraper,
  giphy_api_key: "l1MVxzThwGtvCk8h6ORdTtBYMP0QP88q",
  giphy_url: "https://api.giphy.com/v1/gifs/"
